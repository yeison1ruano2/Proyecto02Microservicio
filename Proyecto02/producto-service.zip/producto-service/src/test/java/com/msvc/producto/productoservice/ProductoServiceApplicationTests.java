package com.msvc.producto.productoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
